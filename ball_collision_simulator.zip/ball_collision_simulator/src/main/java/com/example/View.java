package com.example;

import com.example.utils.Ball;
import com.example.utils.Grid;

import javax.swing.*;
import java.awt.*;
import java.awt.geom.Rectangle2D;
import java.util.List;

public class View extends JPanel {
    public static final int FPS = 600;

    private int frames = 0;
    private long lastFpsTime = System.nanoTime();
    private int fps = 0;

    private final Simulation simulation;

    View(Simulation simulation){
        this.simulation = simulation;

        setBackground(Color.BLACK);
        Rectangle2D bounds = simulation.bounds();
        setPreferredSize(new Dimension(
                (int) (2 * bounds.getX() + bounds.getWidth()),
                (int) (2 * bounds.getY() + bounds.getHeight()))
        );
        new Thread(this::run).start();
    }

    private void run(){
        double frameTime = 1_000_000_000.0 / FPS;
        double delta = 0;
        long last = System.nanoTime();
        while(true){
            long now = System.nanoTime();
            delta += now - last;
            last = now;
            if(delta >= frameTime){
                delta -= frameTime;
                simulation.update();
                repaint();

                frames++;
                if(now - lastFpsTime >= 1_000_000_000){
                    fps = frames;
                    frames = 0;
                    lastFpsTime = now;
                }
            }
        }
    }

    @Override
    protected void paintComponent(Graphics g){
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g;

        g2.setColor(Color.WHITE);
        g2.draw(simulation.bounds());

        drawBalls(g2, simulation.balls());

        g2.setColor(Color.BLUE);
//        drawTrajectory(g2, sim.balls());

        g2.setColor(Color.GRAY);
//        drawGrid(g2, simulation.grid());

        g2.setColor(Color.WHITE);
        g2.drawString("FPS: " + fps, 10, 20);
        g2.drawString("Balls: " + simulation.balls().size(), 10, 40);
    }

    private void drawBalls(Graphics2D g2, List<Ball> balls){
        for(Ball ball : balls){
            int x = (int) ball.position.getX();
            int y = (int) ball.position.getY();
            int r = (int) ball.radius;
            g2.setColor(color(ball.id));
            g2.fillOval(x-r, y-r, r*2, r*2);
        }
    }

    private static void drawTrajectory(Graphics2D g2, List<Ball> balls){
        for(Ball ball : balls){
            int x = (int) ball.position.getX();
            int y = (int) ball.position.getY();

            g2.drawLine(x, y, (int) (x + ball.velocity.getX()/5), (int) (y + ball.velocity.getY()/5));
        }
    }

    private void drawGrid(Graphics2D g2, Grid<?> grid){
        for(Point cell : grid.cells()){
            double w = grid.cellWidth;
            double h = grid.cellHeight;
            int x = (int) (cell.x * w);
            int y = (int) (cell.y * h);
            g2.drawRect(x, y, (int) w, (int) h);
        }
    }

    private Color color(int id){
        return switch(id % 5){
            case 0 -> Color.WHITE;
            case 1 -> Color.RED;
            case 2 -> Color.GREEN;
            case 3 -> Color.CYAN;
            case 4 -> Color.YELLOW;
            default -> throw new IllegalStateException("Unexpected value: " + id);
        };
    }
}