package com.example;

import com.example.utils.Ball;
import com.example.utils.ImmutableVector;
import com.example.utils.Grid;

import javax.swing.*;
import java.awt.Point;
import java.awt.geom.Rectangle2D;
import java.util.ArrayList;
import java.util.List;

public class Main{
    private static final int ROWS = 12*2;
    private static final int COLS = 16*2;

    private static final int WIDTH = 960;
    private static final int HEIGHT = 720;

    public static void main(String[] args){
        double gravity = 00;

        Rectangle2D bounds = new Rectangle2D.Double(0, 0, WIDTH, HEIGHT);

        int n = 8000;
        double radius = 1;
        List<Ball> balls = spawnBalls(n, radius, bounds);

        double cellWidth = (double) WIDTH / COLS;
        double cellHeight = (double) HEIGHT / ROWS;
        cellWidth = cellHeight = 4*radius;
        Grid<List<Ball>> grid = new Grid<>(cellWidth, cellHeight);
        grid.getCells(bounds).forEach(cell -> grid.set(cell, new ArrayList<>()));

        Simulation simulation = new SimulationSeq(gravity, bounds, balls, grid);

        View panel = new View(simulation);

        JFrame frame = new JFrame("Ball Collision Simulator");
        frame.add(panel);
        frame.pack();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }


    private static List<Ball> spawnBalls(int n, double radius, Rectangle2D bounds){
        List<Ball> balls = new ArrayList<>();
        for(int i = 0; i < n; i++){
            double x = bounds.getX() + Math.random() * bounds.getWidth();
            double y = bounds.getY() + Math.random() * bounds.getHeight();

            Ball b = new Ball(x, y, radius, 1);
            b.velocity = new ImmutableVector((Math.random()-0.5)*1000, (Math.random()-0.5)*1000);
            balls.add(b);
        }
        return balls;
    }
}