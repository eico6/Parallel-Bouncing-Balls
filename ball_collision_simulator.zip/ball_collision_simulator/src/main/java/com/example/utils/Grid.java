package com.example.utils;

import java.awt.Point;
import java.awt.geom.Rectangle2D;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public class Grid<E> implements Iterable<E> {
	public final double cellWidth, cellHeight;
	private final Map<Point, E> grid = new ConcurrentHashMap<>();

	public Grid(double cellWidth, double cellHeight) {
		this.cellWidth = cellWidth;
		this.cellHeight = cellHeight;
	}

	public List<Point> getCells(Rectangle2D r){
		int x1 = (int) Math.floor((r.getX()) / cellWidth);
        int y1 = (int) Math.floor((r.getY()) / cellHeight);
        int x2 = (int) Math.ceil((r.getMaxX()) / cellWidth);
        int y2 = (int) Math.ceil((r.getMaxY()) / cellHeight);

		List<Point> cells = new ArrayList<>();
        for(int x = x1; x < x2; x++){
            for(int y = y1; y < y2; y++){
                cells.add(new Point(x, y));
            }
        }
		return cells;
	}

	public E get(Point cell){
		return grid.get(cell);
	}

	public E getOrDefault(Point cell, E defaultValue){
		return grid.getOrDefault(cell, defaultValue);
	}

	public E set(Point cell, E e){
		return grid.put(cell, e);
	}

	public void clear(){
		grid.clear();
	}

	public Iterable<Point> cells(){
		return grid.keySet();
	}

	@Override
	public Iterator<E> iterator(){
		return grid.values().iterator();
	}
}