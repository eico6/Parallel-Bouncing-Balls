package com.example;

import com.example.utils.Ball;
import com.example.utils.Grid;
import com.example.utils.Vector;

import java.awt.Point;
import java.awt.geom.Rectangle2D;
import java.util.*;

public class SimulationSeq implements Simulation {
    private final double gravity;
    private final Rectangle2D bounds;
    private final List<Ball> balls;
    private final Grid<List<Ball>> grid;

    private final Map<Ball, Set<Ball>> checkedPairs = new HashMap<>();

    public SimulationSeq(double gravity, Rectangle2D bounds, List<Ball> balls, Grid<List<Ball>> grid) {
        this.gravity = gravity;
        this.bounds = bounds;
        this.balls = balls;
        this.grid = grid;

        balls.forEach(ball -> checkedPairs.put(ball, new HashSet<>()));
    }

    @Override
    public void update() {
        grid.clear();
        grid.forEach(Collection::clear);
        checkedPairs.values().forEach(Collection::clear);

        for(Ball b : balls){
            b.velocity = b.velocity.add(0, gravity/ View.FPS);
            b.position = b.position.add(Vector.div(b.velocity, View.FPS));
        }
        for(Ball b : balls){
            resolveWallCollision(b);
        }
        for(Ball b : balls){
            addToGrid(b);
        }

        On();
//        On2();
    }

    private void On(){
        for(List<Ball> balls : grid){
            for(int i = 0; i < balls.size(); i++){
                Ball a = balls.get(i);
                for(int j = i+1; j < balls.size(); j++){
                    Ball b = balls.get(j);
                    if(checkedPairs.get(a).contains(b)){
                        continue;
                    }
                    if(a.overlaps(b)){
                        checkedPairs.get(a).add(b);
                        checkedPairs.get(b).add(a);
                        resolveOverlap(a, b);
                        resolveCollision(a, b);
                    }
                }
            }
        }
    }

    private void On2(){
        for(int i = 0; i < balls.size(); i++){
            Ball a = balls.get(i);
            for(int j = i+1; j < balls.size(); j++){
                Ball b = balls.get(j);
                if(a.overlaps(b)){
                    resolveOverlap(a, b);
                    resolveCollision(a, b);
                }
            }
        }
    }

    private void addToGrid(Ball b){
        Rectangle2D ballBounds = new Rectangle2D.Double(
                b.position.getX() - b.radius,
                b.position.getY() - b.radius,
                2 * b.radius,
                2 * b.radius
        );
        for(Point cell : grid.getCells(ballBounds)){
            if(grid.get(cell) == null) {
                grid.set(cell, new ArrayList<>());
            }
            grid.get(cell).add(b);
        }
    }

    private void resolveWallCollision(Ball b){
        // Left wall
        if (b.position.getX() - b.radius < bounds.getX()){
            b.position.setX(bounds.getX() + b.radius);
            b.velocity.setX(-b.velocity.getX());
        }
        // Right wall
        if (b.position.getX() + b.radius > bounds.getMaxX()){
            b.position.setX(bounds.getMaxX() - b.radius);
            b.velocity.setX(-b.velocity.getX());
        }
        // Bottom wall
        if (b.position.getY() - b.radius < bounds.getY()){
            b.position.setY(bounds.getY() + b.radius);
            b.velocity.setY(-b.velocity.getY());
        }
        // Top wall
        if (b.position.getY() + b.radius > bounds.getMaxY()){
            b.position.setY(bounds.getMaxY() - b.radius);
            b.velocity.setY(-b.velocity.getY());
        }
    }

    private void resolveCollision(Ball a, Ball b){
        Vector AB = a.position.sub(b.position);
        if(AB.isZero()){
            return;
        }

        Vector vAB = a.velocity.sub(b.velocity);

        double AB_scalar = 2/(a.mass+b.mass) * b.mass * vAB.dot(AB) / AB.dot(AB);
        AB = AB.scale(AB_scalar);

        a.velocity = a.velocity.sub(AB);
        b.velocity = b.velocity.add(AB);
    }

    private void resolveOverlap(Ball a, Ball b) {
        Vector AB = a.position.sub(b.position);

        if (AB.isZero()) {
            return;
        }

        double dist = AB.len();
        double overlap = a.radius + b.radius - dist;

        if (overlap <= 0) {
            return;
        }

        Vector normal = AB.div(dist);
        normal = normal.scale(overlap / (a.mass + b.mass));

        a.position = a.position.add(normal.scale(b.mass));
        b.position = b.position.sub(normal.scale(a.mass));
    }

    @Override
    public Rectangle2D bounds(){
        return bounds;
    }

    @Override
    public List<Ball> balls(){
        return balls;
    }

    @Override
    public Grid<?> grid(){
        return grid;
    }
}