package com.example;

import com.example.utils.Ball;
import com.example.utils.Grid;

import java.awt.geom.Rectangle2D;
import java.util.List;

public interface Simulation{
    void update();

    Rectangle2D bounds();

    List<Ball> balls();

    Grid<?> grid();
}
