package com.example;

import com.example.utils.Ball;
import com.example.utils.Grid;
import com.example.utils.ImmutableVector;

import javax.swing.*;
import java.awt.*;
import java.awt.geom.Rectangle2D;
import java.util.ArrayList;
import java.util.List;

public class Main extends JPanel {
    public static final int FPS = 60;

    private int frames = 0;
    private long lastFpsTime = System.nanoTime();
    private int fps = 0;

    private Simulation sim;
    private Rectangle2D ballBounds = new Rectangle2D.Double(100, 100, 800, 600);

    public static void main(String[] args){
        JFrame frame = new JFrame("Ball Collision Simulator");
        JPanel panel = new Main();

        frame.add(panel);
        frame.pack();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }

    private Main(){
        setBackground(Color.BLACK);
        setPreferredSize(new Dimension(1000, 800));

        List<Ball> balls = spawnBalls(200, 4);

        Grid<List<Ball>> grid = new Grid<>(20, 20);
        for(int r = 0; r < grid.rows(); r++){
            for(int c = 0; c < grid.cols(); c++){
                grid.set(r, c, new ArrayList<>());
            }
        }

        sim = new SimulationSeq(ballBounds, balls, grid);

        new Thread(this::run).start();
    }

    private void run(){
        double frameTime = 1_000_000_000.0 / FPS;
        double delta = 0;
        long last = System.nanoTime();
        while(true){
            long now = System.nanoTime();
            delta += now - last;
            last = now;
            if(delta >= frameTime){
                delta -= frameTime;
                sim.update();
                repaint();

                frames++;
                if(now - lastFpsTime >= 1_000_000_000){
                    fps = frames;
                    frames = 0;
                    lastFpsTime = now;
                }
            }
        }
    }

    private List<Ball> spawnBalls(int n, double radius){
        List<Ball> balls = new ArrayList<>();
        for(int i = 0; i < n; i++){
            double x = ballBounds.getX() + Math.random() * ballBounds.getWidth();
            double y = ballBounds.getY() + Math.random() * ballBounds.getHeight();

            Ball b = new Ball(x, y, radius, 1);
            b.velocity = new ImmutableVector(Math.random()*100, Math.random()*100);
            balls.add(b);
        }
        return balls;
    }

    @Override
    protected void paintComponent(Graphics g){
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g;

        g2.setColor(Color.WHITE);
        g2.drawString("FPS: " + fps, 10, 20);
        g2.drawString("Balls: " + sim.balls().size(), 10, 40);

        g2.setColor(Color.WHITE);
        g2.draw(ballBounds);

        drawBalls(g2, sim.balls());

//        g2.setColor(Color.BLUE);
//        drawTrajectory(g2, sim.balls());
//
//        g2.setColor(Color.WHITE);
//        drawCoordinates(g2, sim.balls());
    }

    private void drawBalls(Graphics2D g2, List<Ball> balls){
        for(Ball ball : balls){
            int x = (int) ball.position.getX();
            int y = (int) ball.position.getY();
            int r = (int) ball.radius;
            g2.setColor(color(ball));
            g2.fillOval(x-r, y-r, r*2, r*2);
        }
    }

    private static void drawCoordinates(Graphics2D g2, List<Ball> balls){
        for(Ball ball : balls){
            int x = (int) ball.position.getX();
            int y = (int) ball.position.getY();
            int r = (int) ball.radius;
            int vx = (int) ball.velocity.getX();
            int vy = (int) ball.velocity.getY();

            g2.drawString("(%d, %d)".formatted(x, y), x+r, y);
            g2.drawString("(%d, %d)".formatted(vx, vy), x+r, y+20);
        }
    }

    private static void drawTrajectory(Graphics2D g2, List<Ball> balls){
        for(Ball ball : balls){
            int x = (int) ball.position.getX();
            int y = (int) ball.position.getY();

            g2.drawLine(x, y, (int) (x + ball.velocity.getX()/5), (int) (y + ball.velocity.getY()/5));
        }
    }

    private Color color(Ball ball){
        return switch(ball.id % 5){
            case 0 -> Color.WHITE;
            case 1 -> Color.RED;
            case 2 -> Color.GREEN;
            case 3 -> Color.CYAN;
            case 4 -> Color.YELLOW;
            default -> throw new IllegalStateException("Unexpected value: " + ball.id);
        };
    }
}