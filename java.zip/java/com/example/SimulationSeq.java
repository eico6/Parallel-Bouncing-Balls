package com.example;

import com.example.utils.Ball;
import com.example.utils.Grid;
import com.example.utils.Vector;

import java.awt.geom.Rectangle2D;
import java.util.List;

public class SimulationSeq implements Simulation {
    double gravity = 1000;
    Rectangle2D bounds;
    List<Ball> balls;
    Grid<List<Ball>> grid;

    public SimulationSeq(Rectangle2D bounds, List<Ball> balls, Grid<List<Ball>> grid) {
        this.bounds = bounds;
        this.balls = balls;
        this.grid = grid;
    }

    @Override
    public void update() {
        for(Ball b : balls){
            b.velocity = b.velocity.add(0, gravity/Main.FPS);
            b.position = b.position.add(Vector.div(b.velocity, Main.FPS));
        }
        for(Ball b : balls){
            resolveWallCollision(b);
        }
        for(int i = 0; i < balls.size(); i++){
            Ball a = balls.get(i);
            for(int j = i+1; j < balls.size(); j++){
                Ball b = balls.get(j);
                if(a.overlaps(b)){
                    resolveOverlap(a, b);
                    resolveCollision(a, b);
                }
            }
        }
    }

    void resolveWallCollision(Ball b){
        // Left wall
        if (b.position.getX() - b.radius < bounds.getX()){
            b.position.setX(bounds.getX() + b.radius);
            b.velocity.setX(-b.velocity.getX());
        }

        // Right wall
        if (b.position.getX() + b.radius > bounds.getMaxX()){
            b.position.setX(bounds.getMaxX() - b.radius);
            b.velocity.setX(-b.velocity.getX());
        }

        // Bottom wall
        if (b.position.getY() - b.radius < bounds.getY()){
            b.position.setY(bounds.getY() + b.radius);
            b.velocity.setY(-b.velocity.getY());
        }

        // Top wall
        if (b.position.getY() + b.radius > bounds.getMaxY()){
            b.position.setY(bounds.getMaxY() - b.radius);
            b.velocity.setY(-b.velocity.getY());
        }
    }

    void resolveCollision(Ball a, Ball b){
        Vector AB = a.position.sub(b.position);

        if(AB.isZero()){
            return;
        }
        Vector vAB = a.velocity.sub(b.velocity);

        double AB_scalar = 2/(a.mass+b.mass) * b.mass * vAB.dot(AB) / AB.dot(AB);
        AB = AB.scale(AB_scalar);

        a.velocity = a.velocity.sub(AB);
        b.velocity = b.velocity.add(AB);
    }

    void resolveOverlap(Ball a, Ball b) {
        Vector delta = a.position.sub(b.position);
        double distSq = delta.dot(delta);

        if (distSq == 0) {
            return;
        }

        double dist = Math.sqrt(distSq);
        double overlap = a.radius + b.radius - dist;

        if (overlap <= 0) {
            return;
        }

        Vector normal = delta.div(dist);

        double totalMass = a.mass + b.mass;

        double moveA = overlap * b.mass / totalMass;
        double moveB = overlap * a.mass / totalMass;

        a.position = a.position.add(normal.scale(moveA));
        b.position = b.position.sub(normal.scale(moveB));
    }

    @Override
    public List<Ball> balls(){
        return balls;
    }
}