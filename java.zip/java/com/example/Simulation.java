package com.example;

import com.example.utils.Ball;

import java.util.List;

public interface Simulation{
    void update();

    List<Ball> balls();
}
