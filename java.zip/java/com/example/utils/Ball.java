package com.example.utils;

import com.example.Main;

public class Ball{
    private static int ID;
    public final int id = ID++;
    public Vector position, velocity;
    public final double radius, mass, elasticity;

    public Ball(double x, double y, double radius, double elasticity) {
        this.position = new ImmutableVector(x, y);
        this.velocity = new ImmutableVector(0, 0);
        this.radius = radius;
        this.mass = radius * radius;
        this.elasticity = elasticity;
    }

    public void update() {
        position = position.add(new Vector(velocity).scale(1.0/ Main.FPS));
    }

    public boolean overlaps(Ball other){
        double dx = position.getX() - other.position.getX();
        double dy = position.getY() - other.position.getY();
        double rSum = radius + other.radius;
        return dx*dx + dy*dy <= rSum*rSum;
    }
}