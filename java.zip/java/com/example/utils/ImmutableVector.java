package com.example.utils;

public class ImmutableVector extends Vector {
    public ImmutableVector(double x, double y) {
        super(x, y);
    }

    public ImmutableVector(Vector vector) {
        super(vector);
    }

    public ImmutableVector set(double x, double y) {
        return new ImmutableVector(x, y);
    }

    public static ImmutableVector add(Vector a, Vector b) {
        return new ImmutableVector(a.x + b.x, a.y + b.y);
    }

    @Override
    public ImmutableVector add(double dx, double dy) {
        return new ImmutableVector(x + dx, y + dy);
    }

    @Override
    public ImmutableVector add(Vector vector) {
        return new ImmutableVector(x + vector.x, y + vector.y);
    }

    public static ImmutableVector sub(Vector a, Vector b) {
        return new ImmutableVector(a.x - b.x, a.y - b.y);
    }

    @Override
    public ImmutableVector sub(double x, double y) {
        return new ImmutableVector(this.x - x, this.y - y);
    }

    @Override
    public ImmutableVector sub(Vector vector) {
        return new ImmutableVector(this.x - vector.x, this.y - vector.y);
    }

    public static ImmutableVector scale(Vector vector, double scalar) {
        return new ImmutableVector(vector.x * scalar, vector.y * scalar);
    }

    @Override
    public ImmutableVector scale(double scalar) {
        return new ImmutableVector(this.x * scalar, this.y * scalar);
    }

    public static ImmutableVector div(Vector vector, double divisor) {
        return new ImmutableVector(vector.x / divisor, vector.y / divisor);
    }

    @Override
    public ImmutableVector div(double divisor) {
        return new ImmutableVector(this.x / divisor, this.y / divisor);
    }

    @Override
    public ImmutableVector nor(){
        double len = Math.sqrt(x*x + y*y);
        return new ImmutableVector(x / len, y / len);
    }

    @Override
    public ImmutableVector reverse(){
        return new ImmutableVector(-this.x, -this.y);
    }

    @Override
    public double len() {
        return Math.sqrt(x*x + y*y);
    }

    @Override
    public double len2() {
        return x*x + y*y;
    }

    @Override
    public double distance(Vector vector) {
        double dx = vector.x - x;
        double dy = vector.y - y;
        return Math.sqrt(dx*dx + dy*dy);
    }

    @Override
    public double distance2(Vector vector) {
        double dx = vector.x - x;
        double dy = vector.y - y;
        return dx*dx + dy*dy;
    }

    /**
     * @return A positive number if the angle between {@code this} and the argument is less than 90 degrees. <br>
     * A negative number if the angle between {@code this} and the argument is more than 90 degrees. <br>
     * 0 if the angle between {@code this} and the argument is exactly 90 degrees. <br>
     */
    public double dot(double x, double y) {
        return this.x*x + this.y*y;
    }

    /**
     * @return A positive number if the angle between {@code this} and the argument is less than 90 degrees. <br>
     * A negative number if the angle between {@code this} and the argument is more than 90 degrees. <br>
     * 0 if the angle between {@code this} and the argument is exactly 90 degrees. <br>
     */
    public double dot(ImmutableVector vector) {
        return x*vector.x + y*vector.y;
    }
}