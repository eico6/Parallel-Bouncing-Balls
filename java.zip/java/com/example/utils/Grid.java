package com.example.utils;

import java.util.Arrays;

public class Grid<E>{
	private final Object[][] data;

    public Grid(int rows, int cols) {
		if(rows < 1 || cols < 1) {
			throw new IllegalArgumentException("rows and cols must be greater than 0");
		}
		data = new Object[rows][cols];
    }

	public int rows(){
		return data.length;
	}
	
	public int cols(){
		return data[0].length;
	}

	@SuppressWarnings("unchecked")
	public E get(int r, int c){
		return (E) data[r][c];
	}

	public void set(int r, int c, E e){
		data[r][c] = e;
	}

	public boolean inBounds(int r, int c){
		return 0 <= r && r < rows() && 0 <= c && c < cols();
	}

	@Override
    public String toString(){
        StringBuilder sb = new StringBuilder();
        for(int row = 0; row < rows(); row++){
			sb.append(Arrays.toString(data[row])).append("\n");
        }
        return sb.substring(0, sb.length() - 1);
    }
}